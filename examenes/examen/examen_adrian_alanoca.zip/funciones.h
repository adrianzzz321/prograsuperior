#ifndef FUNCIONES_H
#define FUNCIONES_H
int mostrar_mensaje();
int obtener_numero();
int esPrimo(int num);
int factorial(int num);
int contarDigitos(int num);
int multiplos_3(int num);
#endif 